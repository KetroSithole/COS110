#include "piece.h"
#include "board.h"
#include <iostream>
#include <string>

int main()
{	
	return 0;
}

		
