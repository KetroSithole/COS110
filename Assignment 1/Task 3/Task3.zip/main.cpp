#include "piece.h"
#include "board.h"
#include "solver.h"
#include <iostream>
#include <string>

int main()
{	
	solver test ("list.txt");
	return 0;
}

		
