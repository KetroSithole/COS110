#include "dynamicArray.h"




//Constructor
template <class T>
DynamicArray<T>::DynamicArray(int s)
{
	if (s <= 0)
		throw "Invalid size provided";
	else
	{
		size = s;
		elements = new T*[size];
		for (int index=0;	index<size;		index++)
			elements[index] = nullptr;
		numElements = 0;
	}
}




//Copy constructor
template <class T>
DynamicArray<T>::DynamicArray(const DynamicArray<T> &other)
{
	size = other.size;
	numElements = other.numElements;

	elements = new T*[size];
	for (int index=0;	index<size;		index++)
		elements[index] = other.elements[index];
}




//Overload assignment operator
template <class T>
DynamicArray<T> &DynamicArray<T>::operator=(const DynamicArray<T> &other)
{
	for (int index=0;	index<size;	index++)
		delete elements[index];
	delete [] elements;

	size = other.size;
	numElements = other.numElements;

	elements = new T*[size];
	for (int index=0;	index<size;		index++)
		elements[index] = other.elements[index];

	return *this;
}




//Clone
template <class T>
DynamicArray<T> *DynamicArray<T>::clone()
{
	DynamicArray<T> *clone = new DynamicArray<T>(this->size);

	clone->numElements = this->numElements;

	for (int index=0;	index<size;		index++)
		clone->elements[index] = this->elements[index];
	return clone;
}


//Destructor
template <class T>
DynamicArray<T>::~DynamicArray()
{
	clear();
}




//Insert
template <class T>
void DynamicArray<T>::insert(int index, T element)
{
	if (index >= size)
	{
		int oldSize = size;
		resize(index);
		

		T **array = new T *[size];
		for (int index=0;		index<size;		index++)
		{
			if (elements[index] != nullptr && index < oldSize)
				array[index] = elements[index];
			else
				array[index] = nullptr;
		}

		elements = new T *[size];
		for (int index=0;	index<size;		index++)
			elements[index] = array[index];

		
		elements[index] = new T (element);
		numElements++;
	}

	else if (elements[index] == nullptr)
	{
		elements[index] = new T (element);
		numElements++;
	}
	else
	{
		int firstNull;
		bool status = false;

		for (int count=index;		count<size;		count++)
		{
			if (elements[count] == nullptr)
			{
				firstNull = count;
				status = true;
				break;
			}
		}

		if (status == true)
		{
			for (int move=firstNull;	move>index;		move--)
				elements[move] = elements[move-1];
			elements[index] = new T (element);
			numElements++;
		}
		else
		{
			size++;
			elements[size-1] == nullptr;

			for (int move=size;	move>index;		move--)
				elements[move] = elements[move-1];
			elements[index] = new T (element);
			numElements++;
		}
	}
}




//Remove
template <class T>
T DynamicArray<T>::remove(int index)
{
	if (elements[index] == nullptr)
		throw "empty structue";

	T *item = new T (*(elements[index]));
	
	delete elements[index];
	elements[index] = nullptr;

	for (int move=index;	move<size;		move++)
		elements[move-1] = elements[move];
	elements[size-1] = nullptr;;	
	
	numElements--;
	return *item;
}




//Getter
template <class T>
T DynamicArray<T>::get(int index) const
{
	if (elements[index] == nullptr)
		throw "empty structure";
	return *elements[index];
}




template <class T>
bool DynamicArray<T>::isEmpty()
{
	int count = 0;
	for (int index=0;	index<size;		index++)
	{
		if (elements[index] == nullptr)
			count++;
	}

	if (count == size)
		return true;
	return false;
}




template <class T>
void DynamicArray<T>::clear()
{
	for (int index=0;	index<size;		index++)
	{
		if (elements[index] != nullptr)
		{
			delete elements[index];
			elements[index] = nullptr;
		}
	}
}




//Overloaded extraction operator
template <class T>
ostream &operator<< (ostream &os ,DynamicArray<T> &obj)
{
	obj.print(os);
	return os;
}




//Print
template <class T>
ostream &DynamicArray<T>::print(ostream& os)
{
	os << "[";
	for (int index=0;	index<size;		index++)
	{
		if (elements[index] == nullptr)
		{
			if (index == size -1)
				os << "*";
			else
				os << "*,";
		}
		else
		{
			if (index == size -1)
				os << *(elements[index]);
			else
				os << *(elements[index]) <<",";
		}
	}
	os << "]";
	return os;
}




template <class T>
void DynamicArray<T>::resize (int howMuch)
{
	size = howMuch + 1;
}
	
